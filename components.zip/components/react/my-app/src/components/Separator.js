import React, { Component } from 'react';

export default class Separator extends Component {

  render() {
    return(

<li><hr className="dropdown-divider" /></li>

    )
  }

}
