export default {
  template: `

<li><slot></slot></li>


`}