export default {
	template: `

<li><hr class="dropdown-divider"></li>


`}